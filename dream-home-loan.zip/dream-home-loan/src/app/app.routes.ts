import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { LoanApplicationComponent } from './loan-application/loan-application.component';
import { LoanTrackerComponent } from './loan-tracker/loan-tracker.component';
import { LoanAccountDetailsComponent } from './loan-account-details/loan-account-details.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { FaqComponent } from './faq/faq.component';
import { CalculatorComponent } from './calculator/calculator.component';
import { LogoutComponent } from './logout/logout.component';


export const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'calculator', component: CalculatorComponent},
  { path: 'login', component: LoginComponent},
  { path: 'admin/login', component:LoginComponent},
  { path: 'logout', component: LogoutComponent},
  { path: 'admin/logout', component: LogoutComponent},
  { path: 'application', component: LoanApplicationComponent},
  { path: 'tracker', component: LoanTrackerComponent},
  { path: 'details', component: LoanAccountDetailsComponent},
  { path: 'admin', component: AdminHomeComponent},
  { path: 'aboutus',component:AboutusComponent},
  { path: 'faq',component:FaqComponent},
  { path: 'apply',component:LoanApplicationComponent}
];
