import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { LoanApplicationService } from './loan-application.service';


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,RouterLink,RouterLinkActive, CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  isLogin: boolean = false;  // User login status
  isAdminLogin: boolean = false;  // Admin login status

  constructor(private loanService: LoanApplicationService) {}

  ngOnInit() {
    // Subscribe to user login status
    this.loanService.isLoggedIn$.subscribe((status: boolean) => {
      this.isLogin = status;
    });

    // Subscribe to admin login status
    this.loanService.isAdminLoggedIn$.subscribe((status: boolean) => {
      this.isAdminLogin = status;
    });
  }
}
