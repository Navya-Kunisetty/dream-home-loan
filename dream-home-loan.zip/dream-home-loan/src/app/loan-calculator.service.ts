import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoanCalculatorService {
  private baseUrl = 'http://localhost:8080/api/loans'; // Backend API URL

  constructor(private http: HttpClient) {}

  calculateEligibility(netMonthlyIncome: number): Observable<any> {
    return this.http.post(`${this.baseUrl}/eligibility`, { netMonthlyIncome });
  }

  calculateEmi(loanAmount: number, loanTenure: number): Observable<any> {
    return this.http.post(`${this.baseUrl}/emi`, { loanAmount, loanTenure });
  }
}
