import { Component } from '@angular/core';

@Component({
  selector: 'app-faq',
  standalone: true,
  imports: [],
  templateUrl: './faq.component.html',
  styleUrl: './faq.component.css'
})
export class FaqComponent {
  isFAQOpen: boolean[] = [false, false, false, false]; // Add more entries if you have more FAQs

  // Method to toggle the FAQ
  toggleFAQ(index: number): void {
    // Toggle the FAQ state for the given index
    this.isFAQOpen[index] = !this.isFAQOpen[index];
  }

}
