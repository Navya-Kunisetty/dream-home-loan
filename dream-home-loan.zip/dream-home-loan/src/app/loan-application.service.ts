import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class LoanApplicationService {
  private apiUrl = 'http://localhost:8080/api/loan-applications';
  private apiUrlFile = 'http://localhost:8080/api/files/upload';

  constructor(private http: HttpClient) {}

  // BehaviorSubject for user session management
  private loggedInSubject = new BehaviorSubject<boolean>(false);
  isLoggedIn$ = this.loggedInSubject.asObservable();

  // BehaviorSubject for admin session management
  private adminLoggedInSubject = new BehaviorSubject<boolean>(false);
  isAdminLoggedIn$ = this.adminLoggedInSubject.asObservable();

  // User login and logout
  login() {
    this.loggedInSubject.next(true);
  }

  logout() {
    this.loggedInSubject.next(false);
  }

  // Admin login and logout
  adminLogin() {
    this.adminLoggedInSubject.next(true);
  }

  adminLogout() {
    this.adminLoggedInSubject.next(false);
  }

  // Loan application registration
  registerLoanApplication(formData: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/register`, formData);
  }

  // File upload
  fileUpload(formData: FormData): Observable<any> {
    return this.http.post<any>(`${this.apiUrlFile}`, formData);
  }
}
