import { Component } from '@angular/core';
import { LoanApplicationService } from '../loan-application.service';
import { LoanApplication } from '../models/loan-application';
import { Router } from '@angular/router'; // Import Router for navigation
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-loan-application',
  templateUrl: './loan-application.component.html',
  standalone: true,
  imports: [FormsModule],
  styleUrls: ['./loan-application.component.css'],
})
export class LoanApplicationComponent {
  loanApplication: LoanApplication = {
    personalDetails: {
      firstName: '',
      lastName: '',
      emailId: '',
      password: '',
      confirmPassword: '',
      phoneNumber: '',
      dob: '',
      gender: '',
      nationality: '',
      aadharCardNumber: '',
      panCardNumber: '',
    },
    propertyDetails: {
      propertyLocation: '',
      propertyName: '',
      estimatedCostOfProperty: 0,
    },
    incomeDetails: {
      typeOfEmployment: '',
      retirementAge: 0,
      organizationType: '',
      employerName: '',
      monthlyIncome: 0,
    },
    loanDetails: {
      loanAmountRequested: 0,
      tenureInYears: 0,
      interestRate: 8.5,
      maxLoanAmountGrantable: 4000000,
    },
    loanStatus: 'Pending',
    isVerified: false,
    uploadDocument:[]
  };
  fileUploadForm:any = {
    uploadDocument:[]
  }

  constructor(
    private loanApplicationService: LoanApplicationService,
    private router: Router  // Inject Router for navigation
  ) {}

  // Handle file selection
  onFileSelected(event: any): void {
    const files: File[] = Array.from(event.target.files);
    this.loanApplication.uploadDocument = files;  // Store files in the model
  }

  // Submit loan application
  registerLoanApplication(): void {
    
    let loanApplicationToSubmit = { ...this.loanApplication };

    if (Array.isArray(loanApplicationToSubmit.uploadDocument) && loanApplicationToSubmit.uploadDocument.length === 0) {
      delete loanApplicationToSubmit.uploadDocument;
    }
    console.log(this.loanApplication, "Form value")
    this.loanApplicationService
      .registerLoanApplication(loanApplicationToSubmit)
      .subscribe({
        next: (response) => {
          console.log('Loan Application Registered', response);

          // Assuming the response contains loanId and applicationNumber
        const loanId = response.loanId;
        const applicationNumber = response.applicationNumber;

        // Display the loanId and applicationNumber in an alert box
        alert(`Loan Application Registered Successfully!\nLoan ID: ${loanId}\nApplication Number: ${applicationNumber}`);
        
          // Navigate to home page after successful registration
          this.router.navigate(['/home']); // Redirect to the home page
        },
        error: (error) => {
          console.error('There was an error registering the loan application!', error);
        },
      });
    this.submitFileUpload();

  }
  submitFileUpload(){
    const formData = new FormData();

    // Append loan application data as JSON
    formData.append('file', new Blob([JSON.stringify(this.loanApplication.uploadDocument)], { type: 'application/json' }));

    // Append each file to the FormData object
    this.loanApplication.uploadDocument.forEach((file: File) => {
      formData.append('file', file, file.name);
    });
    this.loanApplicationService
    .fileUpload(formData)
    .subscribe({
      next: (response) => {
        console.log('Loan Application Registered', response);
        // Navigate to home page after successful registration
        this.router.navigate(['/home']); // Redirect to the home page
      },
      error: (error) => {
        console.error('There was an error registering the loan application!', error);
      },
    });
    
  }
}
