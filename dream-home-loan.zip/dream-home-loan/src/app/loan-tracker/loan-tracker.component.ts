import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-loan-tracker',
  standalone: true,
  imports: [CommonModule,ReactiveFormsModule],
  templateUrl: './loan-tracker.component.html',
  styleUrl: './loan-tracker.component.css'
})
export class LoanTrackerComponent {
  loanStatusForm: FormGroup;
  loanStatus: string | null = null;
  error: string | null = null;

  constructor(private http: HttpClient, private fb: FormBuilder) {
    this.loanStatusForm = this.fb.group({
      applicationNumber: ['', Validators.required]
    });
  }

  trackLoanStatus() {
    if (this.loanStatusForm.invalid) {
      this.error = "Please provide a valid Application Number.";
      return;
    }

    const applicationNumber = this.loanStatusForm.get('applicationNumber')?.value;

    this.http.get(`http://localhost:8080/api/loan-applications/status/${applicationNumber}`, { responseType: 'text' })
      .subscribe({
        next: (response: string) => {
          this.loanStatus = response;
          this.error = null;
        },
        error: (err) => {
          this.loanStatus = null;
          this.error = "Loan Application not found or an error occurred.";
        }
      });
  }
}
