import { Component } from '@angular/core';
import { LoanCalculatorService } from '../loan-calculator.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-calculator',
  standalone: true,
  templateUrl: './calculator.component.html',
  styleUrls: ['./calculator.component.css'],
  imports: [CommonModule, FormsModule]
})
export class CalculatorComponent {
  // EMI Calculator fields
  loanAmount!: number;
  loanTenure!: number;
  emiResponse: any;

  // Eligibility Calculator fields
  netMonthlyIncome!: number;
  eligibilityResponse: any;

  constructor(private loanCalculatorService: LoanCalculatorService) {}

  // EMI Calculator Submit
  calculateEmi() {
    this.loanCalculatorService.calculateEmi(this.loanAmount, this.loanTenure).subscribe((response) => {
      // Round the results to 2 decimal places using toFixed()
      this.emiResponse = {
        monthlyEmi: parseFloat(response.monthlyEmi.toFixed(2)),
        totalAmountToBePaid: parseFloat(response.totalAmountToBePaid.toFixed(2)),
        principalAmount: parseFloat(response.principalAmount.toFixed(2)),
        totalInterest: parseFloat(response.totalInterest.toFixed(2))
      };
    });
  }

  // Eligibility Calculator Submit
  calculateEligibility() {
    this.loanCalculatorService.calculateEligibility(this.netMonthlyIncome).subscribe((response) => {
      // Round the eligible loan amount to 2 decimal places
      this.eligibilityResponse = {
        eligibleLoanAmount: parseFloat(response.eligibleLoanAmount.toFixed(2))
      };
    });
  }
}
