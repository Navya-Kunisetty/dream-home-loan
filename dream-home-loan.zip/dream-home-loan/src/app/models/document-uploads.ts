// src/app/models/document-uploads.model.ts
export class DocumentUploads {
    constructor(
      public uploadedDocuments: File[] = []  // Store files as File[] in the frontend
    ) {}
  }
  