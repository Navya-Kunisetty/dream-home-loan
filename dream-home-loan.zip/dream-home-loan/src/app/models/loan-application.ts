import { PersonalDetails } from './personal-details';
import { PropertyDetails } from './property-details';
import { IncomeDetails } from './income-details';
import { LoanDetails } from './loan-details';
import { DocumentUploads } from './document-uploads';

export class LoanApplication {
  constructor(
    public personalDetails: PersonalDetails,
    public propertyDetails: PropertyDetails,
    public incomeDetails: IncomeDetails,
    public loanDetails: LoanDetails,
    public uploadDocument: any,
    public loanStatus: string = 'Pending',
    public isVerified: boolean = false,
    public loanId?: string,
    public applicationNumber?: string
  ) {}
}
