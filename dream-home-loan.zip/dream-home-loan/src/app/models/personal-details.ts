// src/app/models/personal-details.model.ts
export class PersonalDetails {
    constructor(
      public firstName: string,
      public lastName: string,
      public emailId: string,
      public password: string,
      public confirmPassword: string,
      public phoneNumber: string,
      public dob: string,
      public gender: string,
      public nationality: string,
      public aadharCardNumber: string,
      public panCardNumber: string,
      public middleName?: string // Optional parameter at the end
    ) {}
  }
  