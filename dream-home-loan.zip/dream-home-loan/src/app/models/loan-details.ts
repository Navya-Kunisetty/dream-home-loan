// src/app/models/loan-details.model.ts
export class LoanDetails {
    constructor(
      public loanAmountRequested: number,
      public tenureInYears: number,
      public interestRate: number = 8.5, // Default interest rate
      public maxLoanAmountGrantable: number
    ) {}
  }
  