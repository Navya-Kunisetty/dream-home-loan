import { LoanApplication } from './loan-application';

describe('LoanApplication', () => {
  it('should create an instance', () => {
    expect(new LoanApplication()).toBeTruthy();
  });
});
