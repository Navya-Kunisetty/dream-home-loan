import { PersonalDetails } from './personal-details';

describe('PersonalDetails', () => {
  it('should create an instance', () => {
    expect(new PersonalDetails()).toBeTruthy();
  });
});
