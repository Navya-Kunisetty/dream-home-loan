// src/app/models/property-details.model.ts
export class PropertyDetails {
    constructor(
      public propertyLocation: string,
      public propertyName: string,
      public estimatedCostOfProperty: number
    ) {}
  }
  