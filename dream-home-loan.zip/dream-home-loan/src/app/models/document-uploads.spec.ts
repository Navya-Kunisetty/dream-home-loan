import { DocumentUploads } from './document-uploads';

describe('DocumentUploads', () => {
  it('should create an instance', () => {
    expect(new DocumentUploads()).toBeTruthy();
  });
});
