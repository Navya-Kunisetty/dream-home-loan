import { PropertyDetails } from './property-details';

describe('PropertyDetails', () => {
  it('should create an instance', () => {
    expect(new PropertyDetails()).toBeTruthy();
  });
});
