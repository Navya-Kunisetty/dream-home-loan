import { IncomeDetails } from './income-details';

describe('IncomeDetails', () => {
  it('should create an instance', () => {
    expect(new IncomeDetails()).toBeTruthy();
  });
});
