// src/app/models/income-details.model.ts
export class IncomeDetails {
    constructor(
      public typeOfEmployment: string,
      public retirementAge: number,
      public organizationType: string,
      public employerName: string,
      public monthlyIncome: number
    ) {}
  }
  