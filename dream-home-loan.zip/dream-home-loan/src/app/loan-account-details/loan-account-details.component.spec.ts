import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoanAccountDetailsComponent } from './loan-account-details.component';

describe('LoanAccountDetailsComponent', () => {
  let component: LoanAccountDetailsComponent;
  let fixture: ComponentFixture<LoanAccountDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LoanAccountDetailsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LoanAccountDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
