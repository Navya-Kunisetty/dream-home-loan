import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-loan-account-details',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './loan-account-details.component.html',
  styleUrls: ['./loan-account-details.component.css']
})
export class LoanAccountDetailsComponent {
  accountDetails: any = null;
  errorMessage: string | null = null;
  loanId: string = ''; // Loan ID will be entered via input

  constructor(private http: HttpClient) {}

  // Method to fetch account details from the backend
  fetchAccountDetails() {
    this.loanId = this.loanId.trim(); // Trim whitespaces
    if (this.loanId === '') {
      this.errorMessage = 'Please enter a Loan ID.';
      this.accountDetails = null;
      return;
    }
  
    const body = { loanId: this.loanId };
  
    this.http.post(`http://localhost:8080/api/loan-applications/account-details`, body)
      .subscribe({
        next: (data) => {
          this.accountDetails = data;
          this.errorMessage = null;
        },
        error: () => {
          this.errorMessage = "Account not found for the given Loan ID.";
          this.accountDetails = null;
        }
      });
  }
}
      