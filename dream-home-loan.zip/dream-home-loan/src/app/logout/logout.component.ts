import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoanApplicationService } from '../loan-application.service';

@Component({
  selector: 'app-logout',
  standalone: true,
  imports: [],
  templateUrl: './logout.component.html',
  styleUrl: './logout.component.css'
})
export class LogoutComponent {
  constructor(private _loginService: LoanApplicationService, private router: Router) {
    this.logout();
  }

  logout() {
    if (this._loginService.isAdminLoggedIn$) {
      // If admin is logged in, log them out
      this._loginService.adminLogout();
      alert('Logged out');
      this.router.navigate(['/admin/login']);
    } else if (this._loginService.isLoggedIn$) {
      // If user is logged in, log them out
      this._loginService.logout();
      alert('Logged out');
      this.router.navigate(['/login']);
    }
  }
}