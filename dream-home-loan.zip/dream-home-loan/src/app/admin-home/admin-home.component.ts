import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { PersonalDetails } from '../models/personal-details';
interface LoanApplication {
  applicationNumber: string;
  loanId: string;
  incomeDetails: string;
  personalDetails: PersonalDetails;

}
@Component({
  selector: 'app-admin-home',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './admin-home.component.html',
  styleUrl: './admin-home.component.css'
})
export class AdminHomeComponent {
  loanApplications: LoanApplication[] = [];

  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    this.fetchLoanApplications();
  }

  fetchLoanApplications(): void {
    this.http.get<LoanApplication[]>('http://localhost:8080/api/admin/allapplications')
      .subscribe(data => {
        console.log(data);
        this.loanApplications = data;
      });
  }

  handleAction(action: string, loanId: string): void {


    const payload = { action, loanId };

    // Replace with your API endpoint
    this.http.post('http://localhost:8080/api/admin/process', payload)
      .subscribe(response => {
        console.log('Action processed', response);
        // Optionally refresh the list or handle response
        // Show the appropriate alert based on the action
        
        //}
        // Refresh the list or handle response
        this.fetchLoanApplications();
      });
      // var a:string="application " + action +"ed";

      //alert(a);
      if (action.toLocaleLowerCase() == "verify") {
        alert('Application verified');
      } else if (action == 'approve') {
        alert('Application approved and loan account created');
      } else if (action == 'reject') {
        alert('Application rejected');
      }


  }

}

