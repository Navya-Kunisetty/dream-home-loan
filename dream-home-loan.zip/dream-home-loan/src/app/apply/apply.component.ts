import { Component } from '@angular/core';

@Component({
  selector: 'app-apply',
  standalone: true,
  imports: [],
  templateUrl: './apply.component.html',
  styleUrl: './apply.component.css'
})
export class ApplyComponent {

}
