import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LoanApplicationService } from '../loan-application.service';

@Component({
  selector: 'app-login',
  standalone: true,
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
})
export class LoginComponent {
  loginForm: FormGroup;
  adminLoginForm: FormGroup;
  errorMessage: string | null = null;

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private router: Router,
    private _loginService: LoanApplicationService
  ) {
    this.loginForm = this.fb.group({
      emailId: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });
    this.adminLoginForm = this.fb.group({
      adminusername: ['', [Validators.required, Validators.minLength(3)]],
      adminpassword: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  // Handle user login
  onSubmit() {
    if (this.loginForm.invalid) {
      return;
    }

    const loginData = {
      emailId: this.loginForm.get('emailId')?.value,
      password: this.loginForm.get('password')?.value,
    };

    // Use POST request to send login data
    this.http
      .post('http://localhost:8080/api/loan-applications/login', loginData, {
        responseType: 'text',
        withCredentials: true,
      })
      .subscribe({
        next: (response: string) => {
          this._loginService.login(); // Set user as logged in
          alert(response);
          this.router.navigate(['/home']);
        },
        error: (err) => {
          this.handleLoginError(err);
        },
      });
  }

  // Handle admin login
  onSubmitAdmin() {
    if (this.adminLoginForm.invalid) {
      return;
    }

    const loginData = {
      adminusername: this.adminLoginForm.get('adminusername')?.value,
      adminpassword: this.adminLoginForm.get('adminpassword')?.value,
    };

    // Use POST request to send admin login data
    this.http
      .post('http://localhost:8080/api/admin/login', loginData, {
        responseType: 'text',
        withCredentials: true,
      })
      .subscribe({
        next: (response: string) => {
          this._loginService.adminLogin(); // Set admin as logged in
          alert(response);
          this.router.navigate(['/admin']);
        },
        error: (err) => {
          this.handleLoginError(err);
        },
      });
  }

  handleLoginError(err: any) {
    console.error('Error:', err);
    if (err.status === 500) {
      this.errorMessage = 'Internal server error. Please try again later.';
    } else if (err.status === 401) {
      this.errorMessage = 'Invalid email or password.';
    } else {
      this.errorMessage = 'An unknown error occurred. Please try again.';
    }
  }
}
