package com.wipro.training.loan.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.training.loan.model.EligibilityRequest;
import com.wipro.training.loan.model.EligibilityResponse;
import com.wipro.training.loan.model.EmiRequest;
import com.wipro.training.loan.model.EmiResponse;
import com.wipro.training.loan.service.CalculatorService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/loans")
public class CalculatorController {

    private final CalculatorService calculatorService;

    public CalculatorController(CalculatorService calculatorService) {
        this.calculatorService = calculatorService;
    }

    @PostMapping("/eligibility")
    public EligibilityResponse calculateEligibility(@RequestBody EligibilityRequest request) {
        return calculatorService.calculateEligibility(request);
    }

    @PostMapping("/emi")
    public EmiResponse calculateEmi(@RequestBody EmiRequest request) {
        return calculatorService.calculateEmi(request);
    }
}
