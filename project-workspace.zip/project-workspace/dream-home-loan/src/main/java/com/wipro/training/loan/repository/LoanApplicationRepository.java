package com.wipro.training.loan.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.wipro.training.loan.model.LoanApplication;




@Repository
public interface LoanApplicationRepository extends MongoRepository<LoanApplication, String> {
    // Find loan application by email ID in PersonalDetails
    Optional<LoanApplication> findByPersonalDetailsEmailId(String emailId);
 // Find loan application by application number
    Optional<LoanApplication> findByApplicationNumber(String applicationNumber);
    Optional<LoanApplication> findByloanId(String loanId);
}
