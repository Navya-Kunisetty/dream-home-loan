package com.wipro.training.loan.model;

import org.springframework.data.mongodb.core.mapping.Field;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PersonalDetails {

	@Field("first_name")
    @NotBlank(message = "First Name is mandatory")
    private String firstName;
    
    @Field("middle_name")
    private String middleName;
    
    @Field("last_name")
    @NotBlank(message = "Last Name is mandatory")
    private String lastName;
    
    @Field("email_id")
    @NotBlank(message = "Email ID is mandatory")
    @Email(message = "Invalid email format")
    private String emailId;
    
    @Field("password")
    @NotBlank(message = "Password is mandatory")
    @Size(min = 6, message = "Password must be at least 6 characters long")
    private String password;
    
    @Field("confirm_password")
    @NotBlank(message = "Confirm Password is mandatory")
    private String confirmPassword;
    
    @Field("phone_number")
    @NotBlank(message = "Phone Number is mandatory")
    @Pattern(regexp = "\\d{10}", message = "Phone Number must be 10 digits")
    private String phoneNumber;
    
    @Field("date_of_birth")
    @NotBlank(message = "Date of Birth is mandatory")
    private String dob;
    
    @NotBlank(message = "Gender is mandatory")
    private String gender;
    
    @NotBlank(message = "Nationality is mandatory")
    private String nationality;
    
    @Field("aadhar_card_number")
    @NotBlank(message = "Aadhar Card Number is mandatory")
    @Pattern(regexp = "\\d{12}", message = "Aadhar Card Number must be 12 digits")
    private String aadharCardNumber;
    
    @Field("pan_card_number")
    @NotBlank(message = "PAN Card Number is mandatory")
    @Pattern(regexp = "[A-Z]{5}[0-9]{4}[A-Z]{1}", message = "Invalid PAN Card Number format")
    private String panCardNumber;
}
