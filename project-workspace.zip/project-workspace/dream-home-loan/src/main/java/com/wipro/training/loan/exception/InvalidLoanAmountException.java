package com.wipro.training.loan.exception;

public class InvalidLoanAmountException extends RuntimeException {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidLoanAmountException(String message) {
        super(message);
    }
}
