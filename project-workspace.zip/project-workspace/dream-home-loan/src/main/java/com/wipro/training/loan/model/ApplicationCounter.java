package com.wipro.training.loan.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "application_counters")
public class ApplicationCounter {



    @Id
    private String numberId; // e.g., "applicationNumberCounter"
    private long sequence;
    
}
