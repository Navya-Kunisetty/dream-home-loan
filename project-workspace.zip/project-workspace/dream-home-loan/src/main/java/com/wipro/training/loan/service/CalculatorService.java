package com.wipro.training.loan.service;

import org.springframework.stereotype.Service;

import com.wipro.training.loan.exception.InvalidIncomeException;
import com.wipro.training.loan.exception.InvalidLoanAmountException;
import com.wipro.training.loan.model.EligibilityRequest;
import com.wipro.training.loan.model.EligibilityResponse;
import com.wipro.training.loan.model.EmiRequest;
import com.wipro.training.loan.model.EmiResponse;

@Service
public class CalculatorService {

    private static final double INTEREST_RATE = 0.085 / 12; // Monthly interest rate

    public EligibilityResponse calculateEligibility(EligibilityRequest request) {
        if (request.getNetMonthlyIncome() <= 10000) {
            throw new InvalidIncomeException("Monthly income must be greater than Ten Thousand.");
        }

        double eligibleAmount = 60 * (0.6 * request.getNetMonthlyIncome());
        return new EligibilityResponse(eligibleAmount);
    }

    public EmiResponse calculateEmi(EmiRequest request) {
        if (request.getLoanAmount() <= 50000) {
            throw new InvalidLoanAmountException("Loan amount must be greater than Fifty Thousand.");
        }

        if (request.getLoanTenure() <= 0) {
            throw new InvalidLoanAmountException("Loan tenure must be greater than zero.");
        }

        double P = request.getLoanAmount(); // Principal amount
        int n = request.getLoanTenure() * 12; // Loan tenure in months
        double R = INTEREST_RATE;

        // EMI formula
        double emi = P * R * Math.pow(1 + R, n) / (Math.pow(1 + R, n) - 1);

        // Total Amount to be Paid
        double totalAmountToBePaid = emi * n;

        // Total Interest Calculation
        double totalInterest = totalAmountToBePaid - P;

        return new EmiResponse(emi, totalAmountToBePaid, P, totalInterest);
    }
}
