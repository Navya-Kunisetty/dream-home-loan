package com.wipro.training.loan.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.wipro.training.loan.model.Account;

@Repository

public interface AccountRepository extends MongoRepository<Account, String> {
    Optional<Account> findByAccountNumber(String accountNumber);
    Optional<Account> findByLoanApplicationId(String loanApplicationId);
}
