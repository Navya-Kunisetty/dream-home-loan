package com.wipro.training.loan.model;

public class EmiResponse {
    private double monthlyEmi;
    private double totalAmountToBePaid;
    private double principalAmount;
    private double totalInterest;

    public EmiResponse(double monthlyEmi, double totalAmountToBePaid, double principalAmount, double totalInterest) {
        this.monthlyEmi = monthlyEmi;
        this.totalAmountToBePaid = totalAmountToBePaid;
        this.principalAmount = principalAmount;
        this.totalInterest = totalInterest;
    }

    // Getters and Setters
    public double getMonthlyEmi() {
        return monthlyEmi;
    }

    public void setMonthlyEmi(double monthlyEmi) {
        this.monthlyEmi = monthlyEmi;
    }

    public double getTotalAmountToBePaid() {
        return totalAmountToBePaid;
    }

    public void setTotalAmountToBePaid(double totalAmountToBePaid) {
        this.totalAmountToBePaid = totalAmountToBePaid;
    }

    public double getPrincipalAmount() {
        return principalAmount;
    }

    public void setPrincipalAmount(double principalAmount) {
        this.principalAmount = principalAmount;
    }

    public double getTotalInterest() {
        return totalInterest;
    }

    public void setTotalInterest(double totalInterest) {
        this.totalInterest = totalInterest;
    }
}
