package com.wipro.training.loan.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.wipro.training.loan.model.Account;

import com.wipro.training.loan.model.LoanApplication;
import com.wipro.training.loan.repository.AccountRepository;
import com.wipro.training.loan.repository.LoanApplicationRepository;

@Service
public class LoanApplicationService {

    @Autowired
    private LoanApplicationRepository repository;
    
    @Autowired
    private ApplicationNumberService applicationNumberService;
    
    @Autowired
    private SequenceGeneratorService sequenceGeneratorService;
    
    @Autowired
    private BCryptPasswordEncoder passwordEncoder;
    
    @Autowired
    private AccountRepository accountRepository;

    public LoanApplication registerLoanApplication(LoanApplication loanApplication) {
        // Check if an application already exists for this email
        Optional<LoanApplication> existingApplication = repository
            .findByPersonalDetailsEmailId(loanApplication.getPersonalDetails().getEmailId());

        if (existingApplication.isPresent()) {
            throw new RuntimeException("Email already registered.");
        }
        
     // Validate if password and confirmPassword match before encoding
        if (!loanApplication.getPersonalDetails().getPassword().equals(loanApplication.getPersonalDetails().getConfirmPassword())) {
            throw new RuntimeException("Passwords do not match.");
        }
        
        // Generate and set the application number
        String applicationNumber = applicationNumberService.generateApplicationNumber();
        loanApplication.setApplicationNumber("APP-" + applicationNumber);
        
        // Generate the loanId sequence
        long loanIdSequence = sequenceGeneratorService.generateSequence("loanSequence");
        loanApplication.setLoanId("LN-" + loanIdSequence);  // e.g., "LN-1001"

     // Encode the password before saving the application
        String encodedPassword = passwordEncoder.encode(loanApplication.getPersonalDetails().getPassword());
        String encodedConfirmPassword = passwordEncoder.encode(loanApplication.getPersonalDetails().getConfirmPassword());

        loanApplication.getPersonalDetails().setPassword(encodedPassword);
        loanApplication.getPersonalDetails().setConfirmPassword(encodedConfirmPassword);
        // --- Loan Details Handling --- //

        // Calculate the max loan amount grantable based on the applicant's income and property value
        double maxLoanAmount = calculateMaxLoanAmount(
            loanApplication.getIncomeDetails().getMonthlyIncome(), 
            loanApplication.getPropertyDetails().getEstimatedCostOfProperty()
        );


        // Save the loan application
        return repository.save(loanApplication);
    }
    // Helper method to calculate max loan amount based on income and property value
    private double calculateMaxLoanAmount(double monthlyIncome, double estimatedPropertyCost) {
        double maxBasedOnIncome = monthlyIncome * 60;  // Example: 60 months' worth of income
        double maxBasedOnProperty = estimatedPropertyCost * 0.50;  // Example: 50% of the property value
        return Math.min(maxBasedOnIncome, maxBasedOnProperty);
    }


    

    // Login with email and password
    public LoanApplication login(String emailId, String password) {
        Optional<LoanApplication> loanApplication = repository.findByPersonalDetailsEmailId(emailId);

        if (loanApplication.isEmpty()) {
            throw new RuntimeException("Invalid email or password.");
        }

        // Verify the encoded password
        boolean passwordMatches = passwordEncoder.matches(password, loanApplication.get().getPersonalDetails().getPassword());
        if (!passwordMatches) {
            throw new RuntimeException("Invalid email or password.");
        }

        return loanApplication.get();
    }
    

 
    
 // Method for admin to verify a loan application
    public LoanApplication verifyLoanApplication(String loanId) {
//        if (!admin.isPresent()) {
//            throw new RuntimeException("Unauthorized: Only admins can verify loan applications.");
//        }
        
        Optional<LoanApplication> application = repository.findById(loanId);
        if (application.isPresent()) {
            LoanApplication loanApplication = application.get();
            loanApplication.setVerified(true); // Mark the application as verified
            loanApplication.setLoanStatus("Verified");
            return repository.save(loanApplication);
        }
        throw new RuntimeException("Loan application not found.");
    }

 // Method for admin to approve a loan application and create an account
    public LoanApplication approveLoanApplication(String loanId) {
//        if (!admin.isPresent()) {
//            throw new RuntimeException("Unauthorized: Only admins can approve loan applications.");
//        }

        Optional<LoanApplication> application = repository.findById(loanId);
        if (application.isPresent()) {
            LoanApplication loanApplication = application.get();
            if (loanApplication.isVerified()) {
                loanApplication.setLoanStatus("Approved"); // Mark as approved

                // Generate an account for the applicant
                Account newAccount = new Account();
                String generatedAccountNumber = generateAccountNumber();  // Method to generate account number
                newAccount.setAccountNumber(generatedAccountNumber);
                newAccount.setApplicantName(loanApplication.getPersonalDetails().getFirstName() + " " +
                        loanApplication.getPersonalDetails().getLastName());
                newAccount.setBalance(loanApplication.getLoanDetails().getLoanAmountRequested());  // Set loan amount as balance
                newAccount.setLoanApplicationId(loanId);  // Link the account to the loan application

                // Save the new account to the database
                accountRepository.save(newAccount);

                // Save the approved loan application
                return repository.save(loanApplication);
            } else {
                throw new RuntimeException("Loan application must be verified before approval.");
            }
        }
        throw new RuntimeException("Loan application not found.");
    }

    // Method to generate a random account number
    private String generateAccountNumber() {
        return "ACCT-" + (int)(Math.random() * 100000000);  // Generates an account number like ACCT-12345678
    }


    // Method for admin to reject a loan application
    public LoanApplication rejectLoanApplication(String loanId) {
//        if (!admin.isPresent() ) {
//            throw new RuntimeException("Unauthorized: Only admins can reject loan applications.");
//        }

        Optional<LoanApplication> application = repository.findById(loanId);
        if (application.isPresent()) {
            LoanApplication loanApplication = application.get();
            loanApplication.setLoanStatus("Rejected"); // Mark as rejected
            return repository.save(loanApplication);
        }
        throw new RuntimeException("Loan application not found.");
    }

    
    
    
    // Method for applicants to track the loan status
    public String trackLoanStatus(String applicationNumber) {
        Optional<LoanApplication> application = repository.findByApplicationNumber(applicationNumber);
        if (application.isPresent()) {
            return application.get().getLoanStatus(); // Return loan status
        } else {
            throw new RuntimeException("Loan application not found.");
        }
    }

    

    public Optional<LoanApplication> getLoanApplicationById(String id) {
        return repository.findById(id);
    }

    public List<LoanApplication> getAllLoanApplications() {
        return repository.findAll();
    }

    public void deleteLoanApplication(String id) {
        repository.deleteById(id);
    }

    public LoanApplication submitForVerification(String id) {
        Optional<LoanApplication> application = repository.findById(id);
        if (application.isPresent()) {
            LoanApplication loanApplication = application.get();
            loanApplication.setVerified(true); // Mark as verified
            return repository.save(loanApplication);
        }
        return null; // Return null if loan application not found
    }
}

