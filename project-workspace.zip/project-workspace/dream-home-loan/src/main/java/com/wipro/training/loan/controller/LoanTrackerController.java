package com.wipro.training.loan.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.training.loan.service.LoanApplicationService;

@RestController
@RequestMapping("/api/loan-tracker")
public class LoanTrackerController {

    @Autowired
    private LoanApplicationService loanApplicationService;

    // API to track loan status by application number
    @GetMapping("/status/{applicationNumber}")
    public ResponseEntity<String> trackLoanStatus(@PathVariable String applicationNumber) {
        try {
            String loanStatus = loanApplicationService.trackLoanStatus(applicationNumber);
            return new ResponseEntity<>("Loan Status: " + loanStatus, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }
}