package com.wipro.training.loan.model;

public class EligibilityResponse {
    private double eligibleLoanAmount;

    public EligibilityResponse(double eligibleLoanAmount) {
        this.eligibleLoanAmount = eligibleLoanAmount;
    }

    // Getters and Setters
    public double getEligibleLoanAmount() {
        return eligibleLoanAmount;
    }

    public void setEligibleLoanAmount(double eligibleLoanAmount) {
        this.eligibleLoanAmount = eligibleLoanAmount;
    }
}
