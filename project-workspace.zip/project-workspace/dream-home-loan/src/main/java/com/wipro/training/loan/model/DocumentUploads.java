package com.wipro.training.loan.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import org.springframework.data.mongodb.core.mapping.Field;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DocumentUploads {
    @Field("uploaded_documents")
    private List<String> uploadedDocuments; // URLs or paths to uploaded documents
}


