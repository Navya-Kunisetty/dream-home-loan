package com.wipro.training.loan.model;

import org.springframework.data.mongodb.core.mapping.Field;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoanDetails {

	@NotNull
    @Field("loan_amount_requested")
    private double loanAmountRequested;  // Given by the customer

	@NotNull
    @Field("tenure_in_years")
    private int tenureInYears;  // Given by the customer

    @Field("interest_rate")
    private double INTEREST_RATE = 8.5;   //set by admin
    
    


}

