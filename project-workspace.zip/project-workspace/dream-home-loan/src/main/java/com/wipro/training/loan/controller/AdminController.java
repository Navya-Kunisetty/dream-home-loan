package com.wipro.training.loan.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.wipro.training.loan.model.Admin;
import com.wipro.training.loan.model.LoanApplication;
import com.wipro.training.loan.service.AdminService;
import com.wipro.training.loan.service.LoanApplicationService;

import jakarta.validation.Valid;

@CrossOrigin(origins="http://localhost:4200",allowCredentials = "true")
@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;
    
    @Autowired
    private LoanApplicationService service;

    @PostMapping("/register")
    public ResponseEntity<String> registerAdmin(@Valid @RequestBody Admin admin, BindingResult result) {
        if (result.hasErrors()) {
            return ResponseEntity.badRequest().body("Invalid input data");
        }
        adminService.registerAdmin(admin);
        return ResponseEntity.ok("Admin registered successfully");
    }


    
    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody Map<String, String> loginData) {
    	 String username = loginData.get("adminusername");
         String password = loginData.get("adminpassword");
         
         
         System.out.println("*************************************"+username+", "+password);
        Optional<Admin> loggedInAdmin = adminService.login(username, password);
        if (loggedInAdmin.isPresent()) {
        
            return ResponseEntity.ok("Login successful");
            
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid username or password");
        }
    }
    
    @PostMapping("/process")
    public ResponseEntity<String> process(@RequestBody Map<String, Object> request){
    	
    	 String loanId = (String) request.get("loanId");
         String action = (String) request.get("action");
         if(action.equals("verify")) {
        	 service.verifyLoanApplication(loanId);
         }
         if(action.equals("approve")) {
        	 service.approveLoanApplication(loanId);
         }
         if(action.equals("reject")) {
        	 service.rejectLoanApplication(loanId);
         }
         return new ResponseEntity<>("Loan application verified successfully", HttpStatus.OK);
    }
    
    @GetMapping("/allapplications")
    public ResponseEntity<List<LoanApplication>> getAllLoanApplications() {
    	 List<LoanApplication> applications = new ArrayList<>();
    
      applications = service.getAllLoanApplications();
        return new ResponseEntity<>(applications, HttpStatus.OK);
    }
}


