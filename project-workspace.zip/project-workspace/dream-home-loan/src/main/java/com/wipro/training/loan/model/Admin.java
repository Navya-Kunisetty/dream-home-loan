package com.wipro.training.loan.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.wipro.training.loan.validation.ValidEmail;
import com.wipro.training.loan.validation.ValidPassword;


import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "admins") // MongoDB collection
public class Admin {

	@Id
    private String id;

    @NotBlank(message = "Username is required")
    @Size(min = 2, max = 50, message = "Username must be between 2 and 50 characters")
    private String username;

    @NotBlank(message = "Email is required")
    @ValidEmail(message = "Email should be valid")
    private String email;

    @NotBlank(message = "Password is required")
    @ValidPassword(message="Password should be valid")
    @Size(min = 8, message = "Password must be at least 8 characters long")
    private String password;

    @NotNull(message = "Role cannot be null")
    private String role = "ADMIN";
}
