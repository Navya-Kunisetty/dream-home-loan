package com.wipro.training.loan.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.wipro.training.loan.model.Account;

import com.wipro.training.loan.model.LoanApplication;
import com.wipro.training.loan.repository.AccountRepository;
import com.wipro.training.loan.service.LoanApplicationService;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@CrossOrigin(origins="http://localhost:4200",allowCredentials = "true")
@RestController
@RequestMapping("/api/loan-applications")
public class LoanApplicationController {

    @Autowired
    private LoanApplicationService service;
    
    @Autowired
    private AccountRepository accountRepository;
    
    private LoanApplication loanApplication;
    
    @PostMapping("/register")
    public ResponseEntity<LoanApplication> registerLoanApplication(@RequestBody LoanApplication loanApplication) {
        LoanApplication registeredLoanApplication = service.registerLoanApplication(loanApplication);
        return new ResponseEntity<>(registeredLoanApplication, HttpStatus.CREATED);
    }
    

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody Map<String, String> loginData) {
        String emailId = loginData.get("emailId");
        String password = loginData.get("password");

        System.out.println("Email: " + emailId);
        System.out.println("Password: " + password);

        // Call the login service to validate the credentials
        this.loanApplication = service.login(emailId, password);
        return new ResponseEntity<>("Login successful. Welcome, " + loanApplication.getPersonalDetails().getFirstName() + "!", HttpStatus.OK);
    }


    @GetMapping("/{id}")
    public ResponseEntity<LoanApplication> getLoanApplicationById(@PathVariable String id) {
        Optional<LoanApplication> application = service.getLoanApplicationById(id);
        return application.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping
    public ResponseEntity<List<LoanApplication>> getAllLoanApplications() {
        List<LoanApplication> applications = service.getAllLoanApplications();
        return new ResponseEntity<>(applications, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLoanApplication(@PathVariable String id) {
        service.deleteLoanApplication(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/submit/{id}")
    public ResponseEntity<String> submitForVerification(@PathVariable String id) {
        LoanApplication application = service.submitForVerification(id);
        if (application != null) {
            return new ResponseEntity<>("Loan application submitted for verification successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Loan application not found", HttpStatus.NOT_FOUND);
        }
    }
    
 // Endpoint for loan applicants to track loan status
    @GetMapping("/status/{applicationNumber}")
    public ResponseEntity<String> trackLoanStatus(@PathVariable String applicationNumber) {
        String loanStatus = service.trackLoanStatus(applicationNumber);
        return new ResponseEntity<>("Loan Status: " + loanStatus, HttpStatus.OK);
    }

    
    
 // Endpoint to get account details by account number
    @GetMapping("/details/{accountNumber}")
    public ResponseEntity<?> getAccountDetails(@PathVariable String accountNumber) {
        Optional<Account> account = accountRepository.findByAccountNumber(accountNumber);

        if (account.isPresent()) {
            return new ResponseEntity<>(account.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Account not found", HttpStatus.NOT_FOUND);
        }
    }
    
    @PostMapping("/account-details")
    public ResponseEntity<?> getAccountDetailsByLoanId(@RequestBody Map<String, String> request) {
        String loanId = request.get("loanId");
        Optional<Account> account = accountRepository.findByLoanApplicationId(loanId);

        if (account.isPresent()) {
            Account foundAccount = account.get();
            return new ResponseEntity<>(Map.of(
                "accountNumber", foundAccount.getAccountNumber(),
                "balance", foundAccount.getBalance()
            ), HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Account not found for the given Loan ID", HttpStatus.NOT_FOUND);
        }
    }

    
    
}
   


