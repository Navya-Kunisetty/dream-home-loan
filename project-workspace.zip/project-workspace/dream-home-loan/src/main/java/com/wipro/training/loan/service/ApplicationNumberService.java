package com.wipro.training.loan.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.wipro.training.loan.model.ApplicationCounter;

@Service
public class ApplicationNumberService {

    @Autowired
    private MongoTemplate mongoTemplate;

    private static final String COUNTER_ID = "applicationNumberCounter";

    public String generateApplicationNumber() {
        ApplicationCounter counter = mongoTemplate.findAndModify(
            Query.query(Criteria.where("_id").is(COUNTER_ID)),
            new Update().inc("sequence", 1000),
            FindAndModifyOptions.options().returnNew(true).upsert(true),
            ApplicationCounter.class
        );
        return String.format("%06d", counter.getSequence()); // Format as needed
    }
}