package com.wipro.training.loan.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "loanApplications")
public class LoanApplication {
    
	@Id
    private String loanId;
    
    private String applicationNumber;
    private PropertyDetails propertyDetails;
    private PersonalDetails personalDetails;
    private IncomeDetails incomeDetails; 
    private DocumentUploads documentUploads;
    private boolean isVerified; // To track verification status
    private String loanStatus = "Pending";
    private LoanDetails loanDetails;

    
    public String getApplicationNumber() {
        return applicationNumber;
    }

    public void setApplicationNumber(String applicationNumber) {
        this.applicationNumber = applicationNumber;
    }
}
