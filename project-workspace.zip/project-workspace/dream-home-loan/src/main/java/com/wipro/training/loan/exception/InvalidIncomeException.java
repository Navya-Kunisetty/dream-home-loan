package com.wipro.training.loan.exception;

public class InvalidIncomeException extends RuntimeException {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidIncomeException(String message) {
        super(message);
    }
}
