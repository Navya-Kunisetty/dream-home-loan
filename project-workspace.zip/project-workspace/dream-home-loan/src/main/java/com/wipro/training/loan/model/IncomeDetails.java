package com.wipro.training.loan.model;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Field;

import jakarta.validation.constraints.NotNull;

@Data
public class IncomeDetails {

	@NotNull
    @Field("type_of_employment")
    private String typeOfEmployment; // Salaried or Self Employed

	@NotNull
    @Field("retirement_age")
    private int retirementAge; // Age at which the person plans to retire

	@NotNull
    @Field("organization_type")
    private String organizationType; // Type of organization (e.g., Private, Government)

	@NotNull
    @Field("employer_name")
    private String employerName; // Name of the employer
    
	@NotNull
    @Field("monthly_income")
    private double monthlyIncome;
}
