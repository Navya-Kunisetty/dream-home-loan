package com.wipro.training.loan.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "accounts")
public class Account {

	@Id
    private String accountId;
    
    private String accountNumber;
    private String applicantName;
    private double balance;  // The loan amount transferred to the account

    // Reference to the loan application, if needed
    private String loanApplicationId;
}
