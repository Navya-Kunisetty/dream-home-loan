package com.wipro.training.loan.service;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.wipro.training.loan.model.Admin;
import com.wipro.training.loan.repository.AdminRepository;

@Service
public class AdminService {

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public void registerAdmin(Admin admin) {
        // Check if the email is already registered
        Optional<Admin> existingAdmin = adminRepository.findByEmail(admin.getEmail());
        if (existingAdmin.isPresent()) {
            throw new IllegalArgumentException("Email is already registered");
        }

        // Encode the password before saving to MongoDB
        admin.setPassword(passwordEncoder.encode(admin.getPassword()));
        adminRepository.save(admin);
    }

    public Optional<Admin> login(String username, String password) {
        // Find the admin by email
        Optional<Admin> admin = adminRepository.findByUsername(username);
        if (admin.isPresent()) {
            // Check if the provided password matches the encoded password
            if (passwordEncoder.matches(password, admin.get().getPassword())) {
                return admin;
            }
        }
        return Optional.empty();
    }
}
