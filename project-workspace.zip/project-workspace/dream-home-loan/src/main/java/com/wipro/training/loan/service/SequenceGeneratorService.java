package com.wipro.training.loan.service;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.wipro.training.loan.model.DatabaseSequence;



@Service
public class SequenceGeneratorService {

    @Autowired
    private MongoTemplate mongoTemplate;

    // Method to generate the next sequence for a given sequence name (e.g., "loanSequence")
    public long generateSequence(String seqName) {
        DatabaseSequence counter = mongoTemplate.findAndModify(
            Query.query(Criteria.where("_id").is(seqName)),
            new Update().inc("seq", 1000),
            FindAndModifyOptions.options().returnNew(true).upsert(true),
            DatabaseSequence.class
        );
        return !Objects.isNull(counter) ? counter.getSeq() : 1;
    }
}
