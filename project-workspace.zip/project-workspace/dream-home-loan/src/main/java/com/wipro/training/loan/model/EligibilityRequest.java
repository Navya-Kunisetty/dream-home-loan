package com.wipro.training.loan.model;

public class EligibilityRequest {
    private double netMonthlyIncome;

    // Getters and Setters
    public double getNetMonthlyIncome() {
        return netMonthlyIncome;
    }

    public void setNetMonthlyIncome(double netMonthlyIncome) {
        this.netMonthlyIncome = netMonthlyIncome;
    }
}