package com.wipro.training.loan.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import org.springframework.data.mongodb.core.mapping.Field;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PropertyDetails {
	
	@Field("property_location")
    private String propertyLocation;
    
    @Field("property_name")
    private String propertyName;
    
    @Field("estimated_cost")
    private double estimatedCostOfProperty;
}

